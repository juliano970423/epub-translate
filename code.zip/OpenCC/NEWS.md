# Change History of OpenCC

## Version 1.1.8

2024年7月27日

* 修正Node新版本編譯的問題（[#782](https://github.com/BYVoid/OpenCC/issues/782), [#798](https://github.com/BYVoid/OpenCC/issues/798)）。
* 進一步修正Python包生成腳本（[#875](https://github.com/BYVoid/OpenCC/pull/875)）。
* 引入Bazel構建系統以及CI（[#879](https://github.com/BYVoid/OpenCC/pull/879)）。
* 引入Github MSVC CI（[#880](https://github.com/BYVoid/OpenCC/pull/880)）。
* 爲`opencc`命令行工具添加了字典和配置的路徑`--path`參數。
* 更新附帶的`googletest`版本到1.15，`pybind11`到2.13.1，`tclap`到1.2.5。
* 若干轉換字詞修正（[#609](https://github.com/BYVoid/OpenCC/pull/609), [#698](https://github.com/BYVoid/OpenCC/pull/698), [#707](https://github.com/BYVoid/OpenCC/pull/707), [#760](https://github.com/BYVoid/OpenCC/pull/760), [#779](https://github.com/BYVoid/OpenCC/pull/779), [#786](https://github.com/BYVoid/OpenCC/pull/786), [#792](https://github.com/BYVoid/OpenCC/pull/792), [#806](https://github.com/BYVoid/OpenCC/pull/806), [#808](https://github.com/BYVoid/OpenCC/pull/808), [#810](https://github.com/BYVoid/OpenCC/pull/810), [#825](https://github.com/BYVoid/OpenCC/pull/825), [#826](https://github.com/BYVoid/OpenCC/pull/826), [#837](https://github.com/BYVoid/OpenCC/pull/837), [#864](https://github.com/BYVoid/OpenCC/pull/864), [#865](https://github.com/BYVoid/OpenCC/pull/865), [#870](https://github.com/BYVoid/OpenCC/pull/870), [#877](https://github.com/BYVoid/OpenCC/pull/877), [#878](https://github.com/BYVoid/OpenCC/pull/878)）。

## Version 1.1.7

2023年10月15日

* 添加提交時 python 包重建以驗證包生成 ([#822](https://github.com/BYVoid/OpenCC/pull/822))。
* 支持Python 3.12 和 Node 20，移除針對Python 3.7和Node 16的構建 ([#820](https://github.com/BYVoid/OpenCC/pull/820))。
* add mingw-w64 ci ([#802](https://github.com/BYVoid/OpenCC/pull/802))。
* Add support of CMake config modules ([#763](https://github.com/BYVoid/OpenCC/pull/763))。
* 若干其他小修復。

## Version 1.1.6

2022年12月08日

* 修復python3.11 macos構建 ([#744](https://github.com/BYVoid/OpenCC/pull/744))。
* Bump gtest 和 benchmark 以與最新的 github runners 一起工作 ([#747](https://github.com/BYVoid/OpenCC/pull/747))。

## Version 1.1.5

2022年12月03日

* 支持Python 3.11 ([#728](https://github.com/BYVoid/OpenCC/pull/728))。
* Automatically name SO files ([#708](https://github.com/BYVoid/OpenCC/pull/708))
* Add support for Apple silicon build tag ([#716](https://github.com/BYVoid/OpenCC/pull/716))
* 若干其他小修復。

## Version 1.1.4

2022年6月4日

* 支持Python 3.10（[#637](https://github.com/BYVoid/OpenCC/issues/637)）。
* 移除針對Python 2.7、3.5、3.6和Node 10的構建（[#690](https://github.com/BYVoid/OpenCC/issues/690), [#691](https://github.com/BYVoid/OpenCC/issues/691)）。
* 若干其他小修復。

## Version 1.1.3

2021年9月3日

* 修復部分頭文件不能單獨使用的問題（#550）。
* 修復引入系統pybind11的方法（#566）。
* 支持Node.js 16（#597）。
* 支持Python 3.9（#603）。
* 修正轉換錯誤。
* 若干其他小修復。

## Version 1.1.2

2021年3月2日

* 新增香港繁體轉換。
* 根據《通用漢字規範表》修正大量簡體異體字轉換。調整臺灣標準，避免過度轉換。
* 修正編譯兼容性問題，包括並行編譯。
* 修正1.1.0以來引入的性能嚴重下降問題。

## Version 1.1.1

2020年5月22日

* 正式提供[Python](https://pypi.org/project/OpenCC/)接口和TypeScript類型標註。
* 更新動態鏈接庫`SOVERSION`到`1.1`，由於C++內部接口發生變更。
* 進一步改進與Windows MSVC的兼容性。
* 簡化頭文件結構，加快編譯速度。刪除不必要的`using`。
* 修復部分香港標準字。

## Version 1.1.0

2020年5月10日

* 新辭典格式`ocd2`，基於Marisa Trie 0.2.5。辭典大小大幅減少。`STPhrases.ocd`從4.3MB減少到`STPhrases.ocd2`的924KB。
* 升級依賴的rapidjson版本到1.1.0，tclap到1.2.2，gtest到1.11.0。
* 更改「涌/湧」的默認轉換，修正多個詞組轉換。
* 提供Windows的預編譯版本下載（AppVeyor）。
* 增加基準測試結果。

## Version 1.0.6

2020年4月13日

* 正式支持日本語新字體轉換。
* 升級Node.js依賴，改進兼容性。
* 修復多處多平臺編譯和兼容性問題。
* 修正大量轉換錯誤。

## Version 1.0.5

2017年2月6日

* 修正Windows下CMake和Visual Studio的問題。
* 修正FNV Hash的32位編譯警告。
* 增加若干臺灣常用詞彙轉換和異體字轉換。
* 增加和修正若干轉換問題。
* 加快Node模塊編譯速度。
* 增加Node模塊的詞典轉換接口和Promise接口。

## Version 1.0.4

2016年4月1日

* 使編譯時的腳本兼容Python 3。
* 修正Visual C++ 2015的編譯問題。
* 增補臺灣、香港地區用字用詞轉換。
* 更新nan以修正Node.js擴展編譯兼容性問題。

## Version 1.0.3

2015年7月22日

* 添加化學元素臺灣用字轉換。
* 增補100餘組缺失的簡繁轉換字對。
* 增補香港標準字。
* 使用nan解決Node.js擴展編譯兼容性問題。
* 命令行轉換工具支持就地轉換。
* 測試框架遷移到GTest。
* 修正Visual C++的編譯問題。
* 實現無詞典詞彙抽取和分詞算法。
* 優化轉換性能。

## Version 1.0.2

2014年11月8日

* 修正C語言接口的編譯錯誤問題
* 修正默認簡繁轉換文件名錯誤問題
* `DictEntry`增加`Values()`方法

## Version 1.0.1

2014年10月18日

* 使用C++11完全重寫OpenCC
* 修復大量轉換錯誤
* 增加香港繁體轉換

## Version 0.4.3

2013年5月17日

* 增加接口`opencc_convert_utf8_free`
* 修正Node.js插件內存泄漏問題
* 修正Windows下獲取當前目錄的問題

## Version 0.4.2

2013年4月14日

* 修正「阪」、「薰」繁簡轉換
* 增加四對缺失的簡繁轉換
* 增加API文檔，由Doxygen生成
* 重構大量代碼

## Version 0.4.1

2013年3月21日

* 修正Node.js 0.10兼容性問題。
* 從Unihan數據庫增加若干缺失的簡繁轉換單字。

## Version 0.4.0

2013年3月2日

* 修正「雕」「谥」「峯」轉換，新增數百條臺灣科技詞彙。
* 修正命令行-h錯誤。
* 修正長行讀取錯誤。
* 修正錯誤類型拼寫錯誤。
* 修正UTF-8編碼轉換錯誤。
* 自動跳過UTF-8的BOM。
* 修正配置和數據文件相對路徑問題。
* 增加了gyp編譯系統。
* 增加了Node.js接口。

## Version 0.3.0

2011年12月2日

* 增加中國大陸、臺灣地區異體字和習慣用詞轉換功能。
* 修正詞典轉換鏈爲奇數時的緩衝區複製Bug。
* 修正Big Endian平臺上的UTF-8轉換錯誤。
* 修正「齣」「薑」詞組的問題。
* 修正「钁」「卷」「干」「薰」「糉」「蝨」「麺」。
* 增加「綑」到「捆」的繁簡轉換。
* 增加「跡」「蹟」對立。
* 增加「夫」「伕」對立。
* 增加「毀」「譭」「燬」對立。
* 增加「背」「揹」對立。

## Version 0.2.0

2010年12月23日

* 取消libopencc對iconv的依賴。
* 增加UTF8編碼格式錯誤時提示信息。
* 重構Python封裝。
* 修正讀取一行長度超過緩衝區時的UTF8截斷錯誤。
* 使用CMake代替Autotools構建編譯框架。
* 修正包括「拿不準」在內諸多簡繁轉換問題。

## Version 0.1.2

2010年9月16日

* 增加「僅分詞」和「顯示多重候選字詞」的轉換接口。
* 改進辭典文件的結構。
* 修正轉換緩衝區永遠不足的Bug。
* 修正多辭典轉換時略過某個辭典的Bug。
* 修正輸入爲空時轉換的Bug。
* 改進opencc命令行工具參數提示和幫助。

## Version 0.1.1

2010年8月10日

* 增加簡繁混雜到簡體或繁體的轉換。
* 增加多詞典/詞典組的轉換支持。
* 修正big endian平臺上的兼容性問題。
* 修正apple平臺下編譯iconv依賴的問題。
* 修正辭典中詞條長度長度不相等時轉換錯誤的Bug。
* 重構辭典代碼抽象。
* 增加編譯時的測試。
* 分離辭典爲字典和詞典。

## Version 0.1.0

2010年7月28日

* 修正文件名緩衝區不足的Bug。
* libopencc版本更新至1.0.0。
* 分離臺灣特有的繁簡轉換「著」「么」。
* 修改「众」「教」「查」「污」對應默認異體。
* 加入「齧啮」「灩滟」繁簡轉換。
* 增加「岳嶽」一簡對多繁轉換。
* 隱藏不必要的類型，更新接口註釋。

## Version 0.0.5

2010年7月21日

* 修正`wchar_t`兼容性問題，使用`ucs4`。
* 增加Windows移植分支。
* 修正一個文件名緩衝區分配的問題。
* 增加「囉」「溼」「廕」「彷」「徵」繁簡轉換。

## Version 0.0.4

2010年7月16日

* 增加「卹」「牴」「皁」「羶」「薹」等轉換。
* 精簡辭典中大量不必要的數詞（含「千」「萬」）。
* 修正最短路徑分詞時優先後向匹配的實現問題。
* 修正辭典加載兼容性問題，當無法mmap時直接申請內存。
* 修正C++接口在64位平臺下編譯的問題。

## Version 0.0.3

2010年6月22日

* 加入繁體到簡體的轉換。
* 增加提示信息的中文翻譯，使用`GNU Gettext`。
* 增加辭典配置文件支持。
* 修正一些兼容性Bug。

## Version 0.0.2

2010年6月19日

* 分離詞庫。
* 增加平面文件詞庫讀取的支持。
* 增加平面文件詞庫到`Datrie`詞庫的轉換工具`opencc_dict`。
* 提供UTF8文本直接轉換的接口。

## Version 0.0.1

2010年6月11日

* OpenCC初始版本釋出。
* 支持簡繁轉換。
